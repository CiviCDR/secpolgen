'use strict';

angularApp.controller('HeaderCtrl', function ($scope, $location) {
        $scope.$location = $location;
});
