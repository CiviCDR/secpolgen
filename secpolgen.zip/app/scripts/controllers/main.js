'use strict';

angularApp.controller('MainCtrl', function ($scope) {

});
